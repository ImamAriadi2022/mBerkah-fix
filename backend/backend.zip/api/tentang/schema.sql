CREATE TABLE tentang (
    id INT AUTO_INCREMENT PRIMARY KEY,
    history TEXT NOT NULL,
    employees INT NOT NULL,
    location VARCHAR(255) NOT NULL,
    google_map_link VARCHAR(255) NOT NULL,
    google_map_embed TEXT NOT NULL
);

